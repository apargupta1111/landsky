import { useMemo, useState } from 'react';
import { ChevronLeft, Search } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';

export function Gateways() {
  const gateways = useAppStore((s) => s.gateways);
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);
  const setSelectedGatewayId = useAppStore((s) => s.setSelectedGatewayId);

  const [query, setQuery] = useState('');

  const filteredGateways = useMemo(
    () => gateways.filter((gateway) =>
      gateway.id.toLowerCase().includes(query.toLowerCase()) ||
      String(gateway.signal).includes(query.toLowerCase()) ||
      gateway.status.toLowerCase().includes(query.toLowerCase())
    ),
    [gateways, query],
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <button
            onClick={() => setCurrentPage('dashboard')}
            className="inline-flex items-center gap-2 text-sm text-[var(--text-secondary)] hover:text-primary transition-colors mb-3"
          >
            <ChevronLeft className="w-4 h-4" /> Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold">All Gateways</h1>
          <p className="mt-2 text-[var(--text-secondary)]">{gateways.length} total gateways across all projects</p>
        </div>
      </div>

      <div className="glass-panel rounded-3xl border border-[var(--panel-border)] p-4 md:p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-lg font-bold">Gateways Directory</h2>
            <p className="text-sm text-[var(--text-secondary)]">Click on a gateway to view connected lights</p>
          </div>
          <div className="flex items-center bg-black/10 dark:bg-white/10 rounded-full px-3 py-2 border border-[var(--panel-border)] w-full max-w-md">
            <Search className="w-4 h-4 text-[var(--text-secondary)] mr-2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search gateway..."
              className="bg-transparent border-none outline-none w-full text-sm text-[var(--text-primary)] placeholder-[var(--text-secondary)]"
            />
          </div>
        </div>

        <div className="mt-6 overflow-hidden rounded-3xl border border-[var(--panel-border)]">
          <div className="hidden md:grid grid-cols-6 gap-4 bg-black/5 dark:bg-white/5 text-[var(--text-secondary)] text-xs uppercase tracking-wider px-4 py-3 border-b border-[var(--panel-border)]">
            <div>Gateway ID</div>
            <div>Connected</div>
            <div>Online</div>
            <div>Faults</div>
            <div>Signal</div>
            <div>Status</div>
          </div>

          {filteredGateways.length === 0 ? (
            <div className="glass-panel rounded-3xl border border-dashed border-[var(--panel-border)] p-8 text-center text-sm text-[var(--text-secondary)]">
              No gateways match your search.
            </div>
          ) : (
            filteredGateways.map((gateway, index) => {
              const statusClass =
                gateway.status === 'Online'
                  ? 'bg-primary/10 text-primary border-primary/30'
                  : gateway.status === 'Warning'
                    ? 'bg-warning/20 text-warning border-warning/50'
                    : 'bg-error/20 text-error border-error/50';

              return (
                <button
                  key={gateway.id}
                  onClick={() => {
                    setSelectedGatewayId(gateway.id);
                    setCurrentPage('gatewayDetails');
                  }}
                  className={`w-full text-left px-4 py-4 sm:px-5 transition-colors hover:bg-black/5 dark:hover:bg-white/5 ${index % 2 === 0 ? 'bg-white/80 dark:bg-slate-950/80' : 'bg-transparent'}`}
                >
                  <div className="grid grid-cols-6 gap-4 items-center text-sm">
                    <div>
                      <div className="font-semibold">{gateway.id}</div>
                      <div className="text-[var(--text-secondary)] text-xs">{gateway.projectId}</div>
                    </div>
                    <div className="font-semibold">{gateway.connectedLights}</div>
                    <div className="font-semibold">{gateway.onlineLights}</div>
                    <div className="font-semibold text-error">{gateway.faults}</div>
                    <div className="font-semibold">{gateway.signal} dBm</div>
                    <div>
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold border ${statusClass}`}>{gateway.status}</span>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
